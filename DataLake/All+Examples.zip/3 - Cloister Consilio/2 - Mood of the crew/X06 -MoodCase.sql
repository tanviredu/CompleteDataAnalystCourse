INSERT INTO MOODOFCREW (NAME, JOB, MORNINGMOOD, NOONMOOD, EVENINGMOOD)
VALUES 
("Cubie", "Quartermaster", 5, 7,3),
("SQL_Pirate", "Programmer", 10, 10,10),
("Captain Mighty", "Captain", 7, 9,6),
("Ol’Handbroke", "First Mate", 2, 1,3),
("Mr. Swan", "Boatswain", 2, 4,7);