INSERT INTO FIELD (NAME)
VALUES
        ('Guarma'),
        ('Pelegosto');
