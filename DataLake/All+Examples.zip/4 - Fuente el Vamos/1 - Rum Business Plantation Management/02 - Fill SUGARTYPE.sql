INSERT INTO SUGARTYPE (NAME)
VALUES
('Officinarum'),
('Alopecuroidum'),
('Bengalense'),
('Ravennae'),
('Robustum'),
('Spontaneum'),
('Arundinaceum'),
('Fallax'),
('Bengalense');