INSERT INTO WORKER (FIRSTNAME, NAME, HARVESTRATE, LOAN, FIELD)
VALUES
( 'Joe', 'Trader' , 22, 1.5 ,1),
( 'Joe', 'Barbaro' , 22, 1.5 ,1),
( 'Emanual', 'Cortez' , 24, 2,1 ),
( 'Miguel', 'Herran' , 29, 3 ,1),
( 'Alvaro', 'Morte' , 25, 3.5 ,1),
( 'Darko', 'Peric' , 34, 4 ,1),
( 'Enrique', 'Arce' , 9, 0.7 ,0),
( 'Alvaro', 'Morte' , 25, 3.5,0 ),
( 'Darko', 'Peric' , 34, 4 ,0),
( 'Enrique', 'Arce' , 9, 0.7, 0 );